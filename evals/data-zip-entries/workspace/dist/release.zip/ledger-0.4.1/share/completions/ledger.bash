complete -W 'add list report' ledger
