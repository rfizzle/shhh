# ledger

A double-entry ledger for small shops.
